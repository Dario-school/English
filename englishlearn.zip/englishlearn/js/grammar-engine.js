// grammar-engine.js – Grammar exercise logic for EnglishLearn

const GrammarEngine = (() => {

  let topicData   = null;
  let currentLevel = null;
  let exercises   = [];
  let currentIdx  = 0;
  let results     = [];

  // ── Load topic from JSON ──────────────────────────────────────
  async function loadTopic(group, topicId) {
    const path = `topics/${group}/${topicId}.json`;
    const res  = await fetch(path);
    topicData  = await res.json();
    return topicData;
  }

  // ── Start a level ─────────────────────────────────────────────
  function startLevel(levelNum) {
    currentLevel = topicData.levels.find(l => l.level === levelNum);
    if (!currentLevel) throw new Error(`Level ${levelNum} not found`);
    exercises  = [...currentLevel.exercises];
    currentIdx = 0;
    results    = [];
    return exercises.length;
  }

  function currentExercise() { return exercises[currentIdx] || null; }
  function totalExercises()  { return exercises.length; }
  function currentPos()      { return currentIdx; }
  function isDone()          { return currentIdx >= exercises.length; }
  function advance()         { currentIdx++; }

  // ── Check answer ──────────────────────────────────────────────
  function checkAnswer(exercise, userAnswer) {
    const ua   = userAnswer.trim().toLowerCase();
    const correct = Array.isArray(exercise.answer)
      ? exercise.answer.map(a => a.toLowerCase())
      : [exercise.answer.toLowerCase()];
    const ok = correct.includes(ua);
    results.push({ exercise, userAnswer, correct: ok });
    return ok;
  }

  // ── Level 5 (final test): mix exercises from levels 1–4 ───────
  function buildFinalTest() {
    if (!topicData) return [];
    const all = topicData.levels
      .filter(l => l.level < 5)
      .flatMap(l => l.exercises);
    const shuffled = all.sort(() => Math.random() - 0.5);
    return shuffled.slice(0, Math.min(15, shuffled.length));
  }

  function getSummary() {
    const total   = results.length;
    const correct = results.filter(r => r.correct).length;
    return { total, correct, percent: total ? Math.round(correct / total * 100) : 0 };
  }

  // ── Load all topics for overview ─────────────────────────────
  const TOPICS = [
    // Satzbau
    { group: 'satzbau', id: 'word-order',  title: 'Word Order',      desc: 'Statements & questions' },
    { group: 'satzbau', id: 'questions',   title: 'Questions',       desc: 'Wh- and Yes/No questions' },
    // Verben
    { group: 'verben',  id: 'simple-present', title: 'Simple Present', desc: 'Affirmative, negation & questions' },
    { group: 'verben',  id: 'past-tense',     title: 'Past Tense',     desc: 'Simple past regular & irregular' },
    { group: 'verben',  id: 'present-perfect', title: 'Present Perfect', desc: 'Have / has + past participle' },
    // Adjektive
    { group: 'adjektive', id: 'comparatives', title: 'Comparatives', desc: 'Comparing with -er / more' },
    { group: 'adjektive', id: 'superlatives', title: 'Superlatives', desc: 'The -est / most constructions' },
    // Nomen
    { group: 'nomen', id: 'plural',      title: 'Plural Forms',   desc: 'Regular and irregular plurals' },
    { group: 'nomen', id: 'articles',    title: 'Articles',       desc: 'a / an / the usage' },
  ];

  const GROUP_LABELS = {
    satzbau:   '📐 Satzbau',
    verben:    '🔧 Verben',
    adjektive: '🎨 Adjektive',
    nomen:     '📦 Nomen',
  };

  function getTopics()      { return TOPICS; }
  function getGroupLabels() { return GROUP_LABELS; }

  return {
    loadTopic, startLevel, currentExercise, totalExercises, currentPos,
    isDone, advance, checkAnswer, buildFinalTest, getSummary,
    getTopics, getGroupLabels, topicData: () => topicData
  };
})();
